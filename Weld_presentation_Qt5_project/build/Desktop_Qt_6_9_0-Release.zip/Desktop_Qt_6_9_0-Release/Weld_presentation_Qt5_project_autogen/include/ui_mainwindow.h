/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QLabel *weldResultHeaderLabel;
    QLineEdit *weldSearchTypeBox;
    QPushButton *searchButton;
    QListWidget *weldImageList;
    QLabel *weldImageLabel;
    QLabel *classNCommentLabel;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(1920, 1080);
        MainWindow->setStyleSheet(QString::fromUtf8(""));
        MainWindow->setDockNestingEnabled(true);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        centralwidget->setTabletTracking(false);
        weldResultHeaderLabel = new QLabel(centralwidget);
        weldResultHeaderLabel->setObjectName("weldResultHeaderLabel");
        weldResultHeaderLabel->setGeometry(QRect(630, 20, 241, 31));
        QFont font;
        font.setPointSize(30);
        font.setBold(true);
        weldResultHeaderLabel->setFont(font);
        weldResultHeaderLabel->setStyleSheet(QString::fromUtf8("color: black;"));
        weldSearchTypeBox = new QLineEdit(centralwidget);
        weldSearchTypeBox->setObjectName("weldSearchTypeBox");
        weldSearchTypeBox->setGeometry(QRect(1440, 70, 341, 61));
        QFont font1;
        font1.setPointSize(15);
        weldSearchTypeBox->setFont(font1);
        weldSearchTypeBox->setStyleSheet(QString::fromUtf8("border: 3px solid gray;\n"
"border-radius: 8px;\n"
"background-color: white;\n"
"color: black;"));
        weldSearchTypeBox->setAlignment(Qt::AlignmentFlag::AlignCenter);
        searchButton = new QPushButton(centralwidget);
        searchButton->setObjectName("searchButton");
        searchButton->setGeometry(QRect(1440, 140, 341, 41));
        searchButton->setStyleSheet(QString::fromUtf8(""));
        weldImageList = new QListWidget(centralwidget);
        weldImageList->setObjectName("weldImageList");
        weldImageList->setGeometry(QRect(1440, 190, 341, 751));
        QFont font2;
        font2.setPointSize(18);
        font2.setBold(true);
        weldImageList->setFont(font2);
        weldImageList->setStyleSheet(QString::fromUtf8("QListWidget {\n"
"    border: 3px solid gray;\n"
"    border-radius: 8px;\n"
"    background-color: #ffffff;\n"
"	color: black;\n"
"}\n"
""));
        weldImageLabel = new QLabel(centralwidget);
        weldImageLabel->setObjectName("weldImageLabel");
        weldImageLabel->setGeometry(QRect(110, 70, 1246, 364));
        weldImageLabel->setStyleSheet(QString::fromUtf8("background-color: #cbc9cb;\n"
"color: black;\n"
"border: 5px solid gray;\n"
"border-radius:  5px;\n"
"padding: 0px;"));
        weldImageLabel->setScaledContents(true);
        weldImageLabel->setAlignment(Qt::AlignmentFlag::AlignCenter);
        classNCommentLabel = new QLabel(centralwidget);
        classNCommentLabel->setObjectName("classNCommentLabel");
        classNCommentLabel->setGeometry(QRect(110, 490, 1251, 451));
        QSizePolicy sizePolicy(QSizePolicy::Policy::Preferred, QSizePolicy::Policy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(classNCommentLabel->sizePolicy().hasHeightForWidth());
        classNCommentLabel->setSizePolicy(sizePolicy);
        QFont font3;
        font3.setPointSize(16);
        classNCommentLabel->setFont(font3);
        classNCommentLabel->setStyleSheet(QString::fromUtf8("background-color: #cbc9cb;\n"
"color: black;\n"
"border: 5px solid gray;\n"
"border-radius: 20px;\n"
"padding: 30px;"));
        classNCommentLabel->setAlignment(Qt::AlignmentFlag::AlignJustify|Qt::AlignmentFlag::AlignTop);
        classNCommentLabel->setWordWrap(true);
        MainWindow->setCentralWidget(centralwidget);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "Weld results station", nullptr));
        weldResultHeaderLabel->setText(QCoreApplication::translate("MainWindow", "Weld Result", nullptr));
        weldSearchTypeBox->setText(QString());
        weldSearchTypeBox->setPlaceholderText(QCoreApplication::translate("MainWindow", "Nh\341\272\255p MSSV \304\221\341\273\203 v\303\240 \341\272\245n search...", nullptr));
        searchButton->setText(QCoreApplication::translate("MainWindow", "Search", nullptr));
        weldImageLabel->setText(QCoreApplication::translate("MainWindow", "Image here", nullptr));
        classNCommentLabel->setText(QCoreApplication::translate("MainWindow", "Class and comment here", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
