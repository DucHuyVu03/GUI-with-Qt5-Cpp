# CMAKE generated file: DO NOT EDIT!
# Timestamp file for compiler generated dependencies management for Weld_presentation_Qt5_project.
