# CMAKE generated file: DO NOT EDIT!
# Timestamp file for custom commands dependencies management for Weld_presentation_Qt5_project_autogen.
